#!/bin/bash

if [ -f ./DecryptMake ] 
    then 
    ./DecryptMake
    else 
    make
fi